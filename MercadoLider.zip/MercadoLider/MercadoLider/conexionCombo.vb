﻿Imports MySql.Data.MySqlClient
Module conexionCombo
    Dim server As String = "server=localhost; database=mercado_lider; Uid=user333; Pwd=171102,Megals;"
End Module
