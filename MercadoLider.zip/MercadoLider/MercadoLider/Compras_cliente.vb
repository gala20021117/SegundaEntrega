﻿Imports MySql.Data.MySqlClient

Public Class frmComprasCliente
    Dim server As String = "server=localhost; database=mercado_lider; Uid=root; Pwd=;"
    Dim conexion As New MySqlConnection(server)
    Dim cmd As New MySqlCommand
    Dim ds As DataSet = New DataSet
    Dim adaptador As MySqlDataAdapter = New MySqlDataAdapter


    Sub ActualizarSelect()
        Try
            conexion.Open()
            'MsgBox("nos conectamos")
            cmd.Connection = conexion

            cmd.CommandText = "SELECT * FROM compras"
            adaptador.SelectCommand = cmd
            adaptador.Fill(ds, "Tabla")
            grdCompras.DataSource = ds
            grdCompras.DataMember = "Tabla"

            conexion.Close()

            ' MsgBox("Fue ingresado su registro ")

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub frmComprasCliente_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActualizarSelect()
    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        End
    End Sub

End Class