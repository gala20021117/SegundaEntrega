﻿Imports MySql.Data.MySqlClient
Public Class frmAdminProductos
    Dim server As String = "server=localhost; database=mercado_lider; Uid=user333; Pwd=171102,Megals;"
    Dim conexion As New MySqlConnection(server)
    Dim cmd As New MySqlCommand
    Dim ds As DataSet = New DataSet
    Dim adaptador As MySqlDataAdapter = New MySqlDataAdapter
    Dim tabla As DataTable
    Sub ActualizarSelect()
        Try
            conexion.Open()
            'MsgBox("nos conectamos")
            cmd.Connection = conexion

            cmd.CommandText = "Select articulos.Codigo, articulos.Nombre, articulos.Precio, articulos.Descripcion, articulos.IdUsuario, articulos.IdCategoria, categoria.Nombre FROM articulos, categoria WHERE articulos.IdCategoria=categoria.IdCategoria"
            adaptador.SelectCommand = cmd
            adaptador.Fill(ds, "Tabla")
            grdProductos.DataSource = ds
            grdProductos.DataMember = "Tabla"

            conexion.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub frmAdminProductos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            adaptador = New MySqlDataAdapter("SELECT IdCategoria, Nombre FROM categoria", conexion)
            tabla = New DataTable
            adaptador.Fill(tabla)

            Call LlenarComoBox()
        Catch ex As Exception

        End Try


        ActualizarSelect()
    End Sub

    Private Sub btnModificar_Click(sender As Object, e As EventArgs) Handles btnModificar.Click
        Try
            conexion.Open()
            'MsgBox("nos conectamos")
            cmd.Connection = conexion

            cmd.CommandText = "UPDATE `articulos` Set `Nombre` = '" + txtNombre.Text + "', `Precio` = '" + txtPrecio.Text + "', `Descripcion` = '" + txtDesc.Text + "' WHERE `articulos`.`Codigo` = @Codigo;"
            cmd.Prepare()

            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@nombre", txtNombre.Text)
            cmd.Parameters.AddWithValue("@Precio", txtPrecio.Text)
            cmd.Parameters.AddWithValue("@Descripción", txtDesc.Text)
            cmd.Parameters.AddWithValue("@Codigo", txtCodigo.Text)
            cmd.ExecuteNonQuery()

            txtNombre.Clear()
            txtPrecio.Clear()
            txtDesc.Clear()
            txtCodigo.Clear()

            conexion.Close()

            ActualizarSelect()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        End
    End Sub

    Private Sub grdProductos_SelectionChanged(sender As Object, e As EventArgs) Handles grdProductos.SelectionChanged
        If (grdProductos.SelectedRows.Count > 0) Then
            txtNombre.Text = grdProductos.Item("nombre", grdProductos.SelectedRows(0).Index).Value
            txtPrecio.Text = grdProductos.Item("Precio", grdProductos.SelectedRows(0).Index).Value
            txtDesc.Text = grdProductos.Item("Descripcion", grdProductos.SelectedRows(0).Index).Value
            txtCodigo.Text = grdProductos.Item("Codigo", grdProductos.SelectedRows(0).Index).Value
        End If
    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        Dim respuesta As Byte

        respuesta = MsgBox("¿Esta seguro que desea eliminar este registro?", vbYesNo, "Eliminar")
        If respuesta = vbYes Then

            Try
                conexion.Open()
                cmd.Connection = conexion
                cmd.CommandText = "DELETE FROM `articulos` WHERE `articulos`.`Codigo` = @Codigo;"
                cmd.Prepare()
                cmd.Parameters.Clear()

                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text)
                cmd.Parameters.AddWithValue("@Precio", txtPrecio.Text)
                cmd.Parameters.AddWithValue("@Descripcion", txtDesc.Text)
                cmd.Parameters.AddWithValue("@Codigo", txtCodigo.Text)
                cmd.ExecuteNonQuery()

                txtNombre.Clear()
                txtPrecio.Clear()
                txtDesc.Clear()
                txtCodigo.Clear()


                conexion.Close()

                ActualizarSelect()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If
    End Sub


    Private Sub LlenarComoBox()
        For Each fila As DataRow In tabla.Rows
            cmbCategoria.Items.Add(fila("IdCategoria"))
            cmbCategoria.Items.Add(fila("Nombre"))
        Next
    End Sub

    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        Try
            conexion.Open()
            cmd = conexion.CreateCommand
            cmd.CommandText = "SELECT * FROM articulos WHERE Nombre LIKE '%@Busqueda%' "
            cmd.Prepare()
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@Busqueda", txtBuscar.Text)
            cmd.ExecuteNonQuery()

            conexion.Close()


        Catch ex As Exception

        End Try
    End Sub
End Class