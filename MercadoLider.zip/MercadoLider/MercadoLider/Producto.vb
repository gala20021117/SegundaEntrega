﻿Public Class frmProducto
    Private Sub btnComprar_Click(sender As Object, e As EventArgs) Handles btnComprar.Click
        frmComprar.Show()

    End Sub

    Private Sub frmProducto_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class