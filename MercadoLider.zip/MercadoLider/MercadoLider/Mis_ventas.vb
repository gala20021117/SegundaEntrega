﻿Imports MySql.Data.MySqlClient
Public Class frmVentas
    Dim server As String = "server=localhost; database=mercado_lider; Uid=user333; Pwd=171102,Megals;"
    Dim conexion As New MySqlConnection(server)
    Dim cmd As New MySqlCommand
    Dim ds As DataSet = New DataSet
    Dim adaptador As MySqlDataAdapter = New MySqlDataAdapter

    Sub ActualizarSelect()
        Try
            conexion.Open()
            'MsgBox("nos conectamos")
            cmd.Connection = conexion

            cmd.CommandText = "SELECT articulos.Nombre, articulos.Descripcion, articulos.IdCategoria, items.Precio, items.Cantidad, compras.PrecioTotal, compras.Fecha FROM articulos, items, compras WHERE articulos.Codigo=items.IdArticulo AND compras.IdCompra=items.IdCompra"
            adaptador.SelectCommand = cmd
            adaptador.Fill(ds, "Tabla")
            grdVentas.DataSource = ds
            grdVentas.DataMember = "Tabla"

            conexion.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        End
    End Sub

    Private Sub frmMisPublicaciones_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActualizarSelect()
    End Sub

End Class