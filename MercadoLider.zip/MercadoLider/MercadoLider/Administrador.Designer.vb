﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdministrador
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAdministrador))
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.btnVentasVendedor = New System.Windows.Forms.Button()
        Me.btnAdminProd = New System.Windows.Forms.Button()
        Me.btnComprasCliente = New System.Windows.Forms.Button()
        Me.btnAdminUsuarios = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.GroupBox4.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.White
        Me.GroupBox4.Controls.Add(Me.btnVentasVendedor)
        Me.GroupBox4.Controls.Add(Me.btnAdminProd)
        Me.GroupBox4.Controls.Add(Me.btnComprasCliente)
        Me.GroupBox4.Controls.Add(Me.btnAdminUsuarios)
        Me.GroupBox4.Font = New System.Drawing.Font("Rubik", 8.999999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(34, 31)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox4.Size = New System.Drawing.Size(318, 176)
        Me.GroupBox4.TabIndex = 28
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Opciones de administrador"
        '
        'btnVentasVendedor
        '
        Me.btnVentasVendedor.BackColor = System.Drawing.Color.LightGray
        Me.btnVentasVendedor.Font = New System.Drawing.Font("Rubik", 8.999999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVentasVendedor.Location = New System.Drawing.Point(20, 124)
        Me.btnVentasVendedor.Margin = New System.Windows.Forms.Padding(2)
        Me.btnVentasVendedor.Name = "btnVentasVendedor"
        Me.btnVentasVendedor.Size = New System.Drawing.Size(277, 28)
        Me.btnVentasVendedor.TabIndex = 5
        Me.btnVentasVendedor.Text = "Ver todas las ventas de un vendedor"
        Me.btnVentasVendedor.UseVisualStyleBackColor = False
        '
        'btnAdminProd
        '
        Me.btnAdminProd.BackColor = System.Drawing.Color.LightGray
        Me.btnAdminProd.Font = New System.Drawing.Font("Rubik", 8.999999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdminProd.Location = New System.Drawing.Point(20, 28)
        Me.btnAdminProd.Margin = New System.Windows.Forms.Padding(2)
        Me.btnAdminProd.Name = "btnAdminProd"
        Me.btnAdminProd.Size = New System.Drawing.Size(277, 28)
        Me.btnAdminProd.TabIndex = 2
        Me.btnAdminProd.Text = "Administrar productos"
        Me.btnAdminProd.UseVisualStyleBackColor = False
        '
        'btnComprasCliente
        '
        Me.btnComprasCliente.BackColor = System.Drawing.Color.LightGray
        Me.btnComprasCliente.Font = New System.Drawing.Font("Rubik", 8.999999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnComprasCliente.Location = New System.Drawing.Point(20, 92)
        Me.btnComprasCliente.Margin = New System.Windows.Forms.Padding(2)
        Me.btnComprasCliente.Name = "btnComprasCliente"
        Me.btnComprasCliente.Size = New System.Drawing.Size(277, 28)
        Me.btnComprasCliente.TabIndex = 4
        Me.btnComprasCliente.Text = "Ver todas las compras de un cliente"
        Me.btnComprasCliente.UseVisualStyleBackColor = False
        '
        'btnAdminUsuarios
        '
        Me.btnAdminUsuarios.BackColor = System.Drawing.Color.LightGray
        Me.btnAdminUsuarios.Font = New System.Drawing.Font("Rubik", 8.999999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdminUsuarios.Location = New System.Drawing.Point(20, 60)
        Me.btnAdminUsuarios.Margin = New System.Windows.Forms.Padding(2)
        Me.btnAdminUsuarios.Name = "btnAdminUsuarios"
        Me.btnAdminUsuarios.Size = New System.Drawing.Size(277, 28)
        Me.btnAdminUsuarios.TabIndex = 3
        Me.btnAdminUsuarios.Text = "Administrar usuarios  "
        Me.btnAdminUsuarios.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(-2, -3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(391, 256)
        Me.PictureBox1.TabIndex = 29
        Me.PictureBox1.TabStop = False
        '
        'btnSalir
        '
        Me.btnSalir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSalir.Location = New System.Drawing.Point(269, 212)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(83, 23)
        Me.btnSalir.TabIndex = 30
        Me.btnSalir.Text = "Salir"
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'frmAdministrador
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(382, 252)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmAdministrador"
        Me.Text = "Administrador"
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents btnVentasVendedor As Button
    Friend WithEvents btnAdminProd As Button
    Friend WithEvents btnComprasCliente As Button
    Friend WithEvents btnAdminUsuarios As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnSalir As Button
End Class
