﻿Imports System.ComponentModel
Imports MySql.Data.MySqlClient
Public Class frmVender
    Dim server As String = "server=localhost; database=mercado_lider; Uid=user333; Pwd=171102,Megals;"
    Dim conexion As New MySqlConnection(server)
    Dim cmd As New MySqlCommand
    Dim adaptador As MySqlDataAdapter
    Dim tabla As DataTable

    Private Sub btnPublicar_Click(sender As Object, e As EventArgs) Handles btnPublicar.Click

        If txtArticulo.Text = "" Or txtDescripcion.Text = "" Or cmbCategoria.Text = "" Or txtPrecio.Text = "" Or cmbProveedor.Text = "" Then
            MsgBox("Ha ocurrido un error, porfavor llena los campos correspondientes", MsgBoxStyle.Critical + vbOK)
        ElseIf txtArticulo.Text <> "" Or txtDescripcion.Text <> "" Or cmbCategoria.Text <> "" Or txtPrecio.Text <> "" Then

            Try
                conexion.Open()
                cmd = conexion.CreateCommand
                cmd.CommandText = "INSERT INTO articulos(Nombre, Descripcion, IdCategoria, Precio, IdUsuario, FotoPortada) VALUES (@Nombre, @Descripcion, @IdCategoria, @Precio, @IdUsuario, @FotoPortada)"

                cmd.Prepare()
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@Nombre", txtArticulo.Text)
                cmd.Parameters.AddWithValue("@Descripcion", txtDescripcion.Text)
                cmd.Parameters.AddWithValue("@IdCategoria", cmbCategoria.Text)
                cmd.Parameters.AddWithValue("@Precio", txtPrecio.Text)
                cmd.Parameters.AddWithValue("@IdUsuario", cmbProveedor.Text)
                cmd.Parameters.AddWithValue("@FotoPortada", opImagen.FileName)
                cmd.ExecuteNonQuery()
                'MsgBox("Conexión establecida.")

                txtArticulo.Clear()
                txtDescripcion.Clear()
                txtPrecio.Clear()
                cmbCategoria.Text = ""
                cmbProveedor.Text = ""

                conexion.Close()

                MsgBox("Datos ingresados correctamente")

            Catch ex As Exception
                MsgBox(ex.Message)
                conexion.Close()
            End Try
        End If


    End Sub

    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        End
    End Sub

    Private Sub LlenarComboBox()
        For Each fila As DataRow In tabla.Rows
            cmbProveedor.Items.Add(fila("Nombre"))
            cmbProveedor.Items.Add(fila("IdUsuario"))
        Next
    End Sub

    Private Sub LlenarComoBox2()
        For Each fila As DataRow In tabla.Rows
            cmbCategoria.Items.Add(fila("IdCategoria"))
            cmbCategoria.Items.Add(fila("Nombre"))
        Next
    End Sub
    Private Sub frmVender_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            adaptador = New MySqlDataAdapter("SELECT Nombre, IdRol, IdUsuario FROM usuarios WHERE `IdRol` = '2'", conexion)
            tabla = New DataTable
            adaptador.Fill(tabla)

            Call LlenarComboBox()

            adaptador = New MySqlDataAdapter("SELECT IdCategoria, Nombre FROM categoria", conexion)
            tabla = New DataTable
            adaptador.Fill(tabla)

            Call LlenarComoBox2()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub



    Private Sub cmbProveedor_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbProveedor.KeyPress
        If Char.IsNumber(e.KeyChar) Or Char.IsControl(e.KeyChar) Or Char.IsSeparator(e.KeyChar) Or Char.IsLetter(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbCategoria_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbCategoria.KeyPress
        If Char.IsNumber(e.KeyChar) Or Char.IsControl(e.KeyChar) Or Char.IsSeparator(e.KeyChar) Or Char.IsLetter(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub btnAgregarImag_Click(sender As Object, e As EventArgs) Handles btnAgregarImag.Click
        If opImagen.ShowDialog() = DialogResult.OK Then
            pxImagen.Load(opImagen.FileName)
        End If
    End Sub

End Class