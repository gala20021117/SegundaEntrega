﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdminUsuarios
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAdminUsuarios))
        Me.btnEliminarUs = New System.Windows.Forms.Button()
        Me.btnDesactivar = New System.Windows.Forms.Button()
        Me.btnActivar = New System.Windows.Forms.Button()
        Me.grdUsuarios = New System.Windows.Forms.DataGridView()
        Me.txtBuscarUs = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtBuscar = New System.Windows.Forms.Button()
        CType(Me.grdUsuarios, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnEliminarUs
        '
        Me.btnEliminarUs.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEliminarUs.Location = New System.Drawing.Point(832, 382)
        Me.btnEliminarUs.Margin = New System.Windows.Forms.Padding(2)
        Me.btnEliminarUs.Name = "btnEliminarUs"
        Me.btnEliminarUs.Size = New System.Drawing.Size(129, 28)
        Me.btnEliminarUs.TabIndex = 23
        Me.btnEliminarUs.Text = "Eliminar usuario"
        Me.btnEliminarUs.UseVisualStyleBackColor = True
        '
        'btnDesactivar
        '
        Me.btnDesactivar.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDesactivar.Location = New System.Drawing.Point(689, 381)
        Me.btnDesactivar.Margin = New System.Windows.Forms.Padding(2)
        Me.btnDesactivar.Name = "btnDesactivar"
        Me.btnDesactivar.Size = New System.Drawing.Size(129, 28)
        Me.btnDesactivar.TabIndex = 22
        Me.btnDesactivar.Text = "Desactivar"
        Me.btnDesactivar.UseVisualStyleBackColor = True
        '
        'btnActivar
        '
        Me.btnActivar.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnActivar.Location = New System.Drawing.Point(547, 382)
        Me.btnActivar.Margin = New System.Windows.Forms.Padding(2)
        Me.btnActivar.Name = "btnActivar"
        Me.btnActivar.Size = New System.Drawing.Size(129, 28)
        Me.btnActivar.TabIndex = 21
        Me.btnActivar.Text = "Activar"
        Me.btnActivar.UseVisualStyleBackColor = True
        '
        'grdUsuarios
        '
        Me.grdUsuarios.BackgroundColor = System.Drawing.SystemColors.ControlLight
        Me.grdUsuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdUsuarios.Location = New System.Drawing.Point(11, 43)
        Me.grdUsuarios.Margin = New System.Windows.Forms.Padding(2)
        Me.grdUsuarios.Name = "grdUsuarios"
        Me.grdUsuarios.RowHeadersWidth = 51
        Me.grdUsuarios.RowTemplate.Height = 24
        Me.grdUsuarios.Size = New System.Drawing.Size(950, 335)
        Me.grdUsuarios.TabIndex = 20
        '
        'txtBuscarUs
        '
        Me.txtBuscarUs.Location = New System.Drawing.Point(202, 11)
        Me.txtBuscarUs.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBuscarUs.Name = "txtBuscarUs"
        Me.txtBuscarUs.Size = New System.Drawing.Size(416, 20)
        Me.txtBuscarUs.TabIndex = 19
        Me.txtBuscarUs.Text = "Buscar usuarios"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(-1, -1)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1022, 463)
        Me.PictureBox1.TabIndex = 24
        Me.PictureBox1.TabStop = False
        '
        'btnSalir
        '
        Me.btnSalir.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSalir.Location = New System.Drawing.Point(11, 383)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(129, 23)
        Me.btnSalir.TabIndex = 26
        Me.btnSalir.Text = "Salir"
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.MenuBar
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(74, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(123, 16)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "Buscar usuarios:"
        '
        'txtBuscar
        '
        Me.txtBuscar.Location = New System.Drawing.Point(623, 9)
        Me.txtBuscar.Name = "txtBuscar"
        Me.txtBuscar.Size = New System.Drawing.Size(75, 23)
        Me.txtBuscar.TabIndex = 28
        Me.txtBuscar.Text = "Buscar"
        Me.txtBuscar.UseVisualStyleBackColor = True
        '
        'frmAdminUsuarios
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1021, 459)
        Me.Controls.Add(Me.txtBuscar)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.btnEliminarUs)
        Me.Controls.Add(Me.btnDesactivar)
        Me.Controls.Add(Me.btnActivar)
        Me.Controls.Add(Me.grdUsuarios)
        Me.Controls.Add(Me.txtBuscarUs)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmAdminUsuarios"
        Me.Text = "Admin_usuarios"
        CType(Me.grdUsuarios, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnEliminarUs As Button
    Friend WithEvents btnDesactivar As Button
    Friend WithEvents btnActivar As Button
    Friend WithEvents grdUsuarios As DataGridView
    Friend WithEvents txtBuscarUs As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnSalir As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents txtBuscar As Button
End Class
