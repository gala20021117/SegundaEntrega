﻿Imports System.ComponentModel
Imports MySql.Data.MySqlClient

Public Class frmIngreso
    Dim server As String = "server=localhost; database=mercado_lider; Uid=user333; Pwd=171102,Megals;"
    Dim conexion As New MySqlConnection(server)
    Dim cmd As New MySqlCommand
    Private Sub btnIngresar_Click(sender As Object, e As EventArgs) Handles btnIngresar.Click

        If txtCI.Text <> String.Empty And txtContraseña.Text <> String.Empty Then
            Try
                conexion.Open()
                cmd = conexion.CreateCommand
                cmd.CommandText = "SELECT IdUsuario, Contraseña FROM usuarios WHERE IdUsuario=@IdUsuario AND Contraseña=@Contraseña"
                cmd.Prepare()
                cmd.Parameters.Clear()

                cmd.Parameters.AddWithValue("@IdUsuario", txtCI.Text)
                cmd.Parameters.AddWithValue("@Contraseña", txtContraseña.Text)
                cmd.ExecuteNonQuery()
                'MsgBox("Conexión establecida.")
                conexion.Close()

                txtCI.Clear()
                txtContraseña.Clear()

                MessageBox.Show("Datos correctamente ingresados", "Registro de usuarios", MessageBoxButtons.OK, MessageBoxIcon.Information)
                frmMenu.Show()
            Catch ex As Exception
                MsgBox(ex.Message)
                conexion.Close()
            End Try

        Else
            MsgBox("Ha ocurrido un error, porfavor llena los campos correspondientes", MsgBoxStyle.Critical + vbOK)

        End If


    End Sub



    Private Sub txtEmail_Validating(sender As Object, e As CancelEventArgs) Handles txtCI.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un Email")

        End If
    End Sub

    Private Sub txtContraseña_Validating(sender As Object, e As CancelEventArgs) Handles txtContraseña.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese su contraseña")

        End If
    End Sub
    Private Sub lblContraseña_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblContraseña.LinkClicked
        frmContraseña.Show()


    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        End
    End Sub

    Private Sub frmIngreso_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class